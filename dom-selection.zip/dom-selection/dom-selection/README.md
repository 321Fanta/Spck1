# DOM Selection

A Pen created on CodePen.io. Original URL: [https://codepen.io/sandhikagalih/pen/vdGvRX](https://codepen.io/sandhikagalih/pen/vdGvRX).

